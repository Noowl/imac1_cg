#include <SDL/SDL.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <stdlib.h>
#include <stdio.h>

/* Dimensions de la fenêtre */
static unsigned int WINDOW_WIDTH = 400;
static unsigned int WINDOW_HEIGHT = 400;

/* Nombre de bits par pixel de la fenêtre */
static const unsigned int BIT_PER_PIXEL = 32;

/* Nombre minimal de millisecondes separant le rendu de deux images */
static const Uint32 FRAMERATE_MILLISECONDS = 1000 / 60;

/* Déclaration des structures points et primitives */
    typedef struct Point{
        float x, y; // Position 2D du point
        unsigned char r, g, b; // Couleur du point
        struct Point* next; // Point suivant à dessiner
    } Point, *PointList;

    typedef struct Primitive{
        GLenum primitiveType;
        PointList points;
        struct Primitive* next;
    } Primitive, *PrimitiveList;

/* Fonctions Fonctions liées aux points */

/* Fonction qui alloue la mémoire nécessaire pour un Point, initialise ses champs avec les valeurs x,y,r,g,b passées en paramètre et renvoie le pointeur vers cet espace mémoire */
Point* allocPoint(float x, float y, unsigned char r, unsigned char g, unsigned char b){
    Point* point;
    point = malloc(sizeof(Point));
    /* Message d'erreur si l'allocation n'a pas fonctionné */
    if (point == NULL)
    {
        printf("Erreur d'allocation de mémoire\n");
        exit(EXIT_FAILURE);
    }
    point->x = x;
    point->y = y;
    point->r = r;
    point->g = g;
    point->b = b;
    point->next = NULL;
    return point;
}
/* Fonction qui ajoute l'adresse d'un Point passé en paramètre à une liste chainée passée en paramètre sans valeur de retour */
void addPointToList(Point* point, PointList* list){
    PointList* tmpList;
    tmpList = list;
    if (*tmpList == NULL) {
        *tmpList = point;
    } else {
        point->next = *tmpList;
        *tmpList = point;
    }
    *list = *tmpList;

}
/* Fonction qui dessine les Points de la liste passée en paramètre sans valeur de retour */
void drawPoints(PointList list){
    while (list) {
        glColor3ub(list->r, list->g, list->b);
        glVertex2f(list->x, list->y);
        list = list->next;
    }
}
/* Fonction qui vide la mémoire de tous les Points de la liste passée en paramètre sans valeur de retour */
void deletePoints(PointList* list){
    while (*list) {
        PointList next = (*list)->next;
        free(*list);
        *list = next;
    }
}

/* Fonctions Fonctions liées aux primitives */

/* Fonction qui alloue la mémoire nécessaire pour une Primitive, initialise ses champs avec le type de primitive passé en paramètre ou a NULL et renvoie le pointeur vers cet espace mémoire */
Primitive* allocPrimitive(GLenum primitiveType){
    Primitive* primitive;
    primitive = malloc(sizeof(Primitive));
    /* Message d'erreur si l'allocation n'a pas fonctionné */
    if (primitive == NULL)
    {
        printf("Erreur d'allocation de mémoire\n");
        exit(EXIT_FAILURE);
    }
    primitive->primitiveType = primitiveType;
    primitive->points = NULL;
    primitive->next = NULL;
    return primitive;
}
/* Fonction qui ajoute l'adresse d'une Primitive passée en paramètre à une liste chainée passée en paramètre sans valeur de retour */
void addPrimitive(Primitive* primitive, PrimitiveList* list){
    PrimitiveList tmpList;
    tmpList = *list;
    if (*list == NULL) {
        *list = primitive;
    } else {
        primitive->next = *list;
        *list = primitive;
    }
}
/* Fonction qui dessine les Primitives de la liste passée en paramètre sans valeur de retour */
void drawPrimitives(PrimitiveList list){
    while (list) {
        glBegin(list->primitiveType);
            drawPoints(list->points);
        glEnd();
        list = list->next;
    }
}
/* Fonction qui vide la mémoire de toutes les Primitives de la liste passée en paramètre sans valeur de retour */
void deletePrimitive(PrimitiveList* list){
    while (*list) {
        deletePoints(&((*list)->points));
        PrimitiveList next = (*list)->next;
        free(*list);
        *list = next;
    }
}

/* Fonctions d'affichage */

/* Fonction qui ne retourne rien et redimensionne la fenêtre et le viewport */
void resizeModif(){
	SDL_SetVideoMode(WINDOW_WIDTH, WINDOW_HEIGHT, BIT_PER_PIXEL, SDL_OPENGL | SDL_RESIZABLE | SDL_GL_DOUBLEBUFFER);
    glViewport(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1., 1., -1., 1.);
}

/* Fonction qui ne retourne rien et dessine la palette de couleurs */
void drawPalette(){
    int nb_color, i, r, g, b;
    float color_width;
    nb_color = 8;
    color_width = 2 * WINDOW_WIDTH / (float)nb_color * 100 / WINDOW_WIDTH / 100 ;
    glBegin(GL_QUADS);
        for(i = 0; i < nb_color; ++i) {
            switch (i){
                case 0:
                    r = 255;
                    g = 255;
                    b = 255;
                    break;
                case 1:
                    r = 0;
                    g = 0;
                    b = 0;
                    break;
                case 2:
                    r = 255;
                    g = 0;
                    b = 0;
                    break;
                case 3:
                    r = 0;
                    g = 255;
                    b = 0;
                    break;
                case 4:
                    r = 0;
                    g = 0;
                    b = 255;
                    break;
                case 5:
                    r = 255;
                    g = 255;
                    b = 0;
                    break;
                case 6:
                    r = 0;
                    g = 255;
                    b = 255;
                    break;
                case 7:
                    r = 255;
                    g = 0;
                    b = 255;
                    break;
                default:
                    break;
            }
            glColor3ub(r, g, b);
            glVertex2f(-1 + i * color_width, -1);
            glVertex2f(-1 + (i + 1) * color_width, -1);
            glVertex2f(-1 + (i + 1) * color_width, 1);
            glVertex2f(-1 + i * color_width, 1);
        }
    glEnd();
}

/* Fonction qui ne retourne rien et attribue au variables r,g,b dont l'adrese est passée en paramètre une couleur en fonction da la position x passée en paramètre */
void colorSelect(int x, int *r, int *g, int *b) {
    int nbColor, numBande;
    nbColor = 8;
    numBande = x / (WINDOW_WIDTH / nbColor);
    switch (numBande){
        case 0:
            *r = 255;
            *g = 255;
            *b = 255;
            break;
        case 1:
            *r = 0;
            *g = 0;
            *b = 0;
            break;
        case 2:
            *r = 255;
            *g = 0;
            *b = 0;
            break;
        case 3:
            *r = 0;
            *g = 255;
            *b = 0;
            break;
        case 4:
            *r = 0;
            *g = 0;
            *b = 255;
            break;
        case 5:
            *r = 255;
            *g = 255;
            *b = 0;
            break;
        case 6:
            *r = 0;
            *g = 255;
            *b = 255;      
            break;
        case 7:
            *r = 255;
            *g = 0;
            *b = 255;
            break;
        default:
            break;
    }
}

/* Fonction principale */
int main(int argc, char** argv) {
    /* GLfloat R = 0, V = 0; Pas utile --> exercice 5 */
    int r,g,b, affichage; /* Composantes de couleurs rgb, affichage : 0 = Dessin | 1 = Choix couleur*/
    float x,y,thickness; /* Cordonnée en x, coordonnées en y, épaisseur du point/trait */
    PrimitiveList primitiveList = NULL; /* Création de la liste de primitives et initialisation à NULL */

    r = g = b = 255; /* Initialisation des  composantes de couleur à blanc */
    affichage = 0; /* Mode dessin par défaut */ 
    x = y = 0.; /* Initialisation des coordonnées à 0 */
    thickness = 2.; /* Initialisation de l'apaisseur à 2 */

    /* Initialisation de la SDL */
    if(-1 == SDL_Init(SDL_INIT_VIDEO)) {
        fprintf(stderr, "Impossible d'initialiser la SDL. Fin du programme.\n");
        return EXIT_FAILURE;
    }
    
    /* Ouverture d'une fenêtre et création d'un contexte OpenGL */
    if(NULL == SDL_SetVideoMode(WINDOW_WIDTH, WINDOW_HEIGHT, BIT_PER_PIXEL, SDL_OPENGL | SDL_GL_DOUBLEBUFFER | SDL_RESIZABLE)) {
        fprintf(stderr, "Impossible d'ouvrir la fenetre. Fin du programme.\n");
        return EXIT_FAILURE;
    }

    resizeModif();
    
    /* Titre de la fenêtre */
    SDL_WM_SetCaption("PaintImac", NULL);
    
    /* Initialisation des paramètres de dessin */
    glColor3ub(r,g,b); 
    glPointSize(thickness); 
    glLineWidth(thickness);

    /* Initialisation à une primitive de type GL_POINTS */
    addPrimitive(allocPrimitive(GL_POINTS), &primitiveList);

    /* Boucle d'affichage */
    int loop = 1;
    while(loop){

        /* Récupération du temps au début de la boucle */
        Uint32 startTime = SDL_GetTicks();
        
        /* Placer ici le code de dessin */

        /* EXERCICE 5
    	glClearColor(R,V,0,150);
            glClear(GL_COLOR_BUFFER_BIT);

    	glColor3ub(r,g,b);

    	glBegin(GL_POINTS);
    		glVertex2f(-1 + 2. * 200 / WINDOW_WIDTH, -(-1 + 2. * 100 /WINDOW_HEIGHT));
    	glEnd();  */

        glColor3ub(r,g,b);
        if (affichage == 0) {
            glClearColor(0,0,0,0);
                glClear(GL_COLOR_BUFFER_BIT);
            drawPrimitives(primitiveList); //On dessine les primitives
        } else {
            drawPalette(); //On affiche les couleurs pour la sélection
        }
        
        /* Boucle traitant les evenements */
        SDL_Event e;
        while(SDL_PollEvent(&e)) {

            /* L'utilisateur ferme la fenêtre : */
            if(e.type == SDL_QUIT) {
                loop = 0;
                break;
            }
            
            /* Quelques exemples de traitement d'evenements : */
            switch(e.type) {

                /* Clic souris */
                case SDL_MOUSEBUTTONDOWN: 
                    switch (affichage) {
                        case 0: /* Dessin : Ajout d'un point */
                            x = -1 + 2. * e.button.x / WINDOW_WIDTH;
                            y = -(-1 + 2. * e.button.y / WINDOW_HEIGHT);
                            addPointToList(allocPoint(x, y, r, g, b), &primitiveList->points);
                            break;
                        case 1: /* Palette : Sélection de la couleur */ 
                            colorSelect(e.button.x, &r, &g, &b);
                            break;
                        default:
                            break;
                    }
                    break;

                /* Touche clavier pushed */
                case SDL_KEYDOWN:
			        switch (e.key.keysym.sym) {
                        case SDLK_SPACE:
                            affichage = 1;
                            break;
                        case SDLK_p:
                            addPrimitive(allocPrimitive(GL_POINTS), &primitiveList);
                            break;
                        case SDLK_l:
                            addPrimitive(allocPrimitive(GL_LINES), &primitiveList);
                            break;
                        case SDLK_t:
                            addPrimitive(allocPrimitive(GL_TRIANGLES), &primitiveList);
                            break;
                        case SDLK_r:
                            addPrimitive(allocPrimitive(GL_QUADS), &primitiveList);
                            break;
                        case SDLK_q:
    				        loop = 0;
    				        break;
                        // case SDLK_c:
                        //     deletePrimitive(&primitiveList);
                        //     break;
                        default:
                            break;
                    }
                    break;

                /* Touche clavier pulled */
                case SDL_KEYUP:
                    switch (e.key.keysym.sym) {
                        case SDLK_SPACE:
                            affichage = 0;
                            glClear(GL_COLOR_BUFFER_BIT);
                            break;
                        default:
                            break;
                    }
                    break;
		        case SDL_MOUSEMOTION:
			        /* Exercice 4
                    R = (float)((e.button.x) % WINDOW_WIDTH)/WINDOW_WIDTH;
		    	    V = (float)((e.button.y) % WINDOW_HEIGHT)/WINDOW_HEIGHT; */
			        break;

        		case SDL_VIDEORESIZE:
        			WINDOW_WIDTH = e.resize.w;
        			WINDOW_HEIGHT = e.resize.h;
        			resizeModif();			
        			break;

                default:
                    break;
            }
        }

        SDL_GL_SwapBuffers();
        /* Calcul du temps écoulé */
        Uint32 elapsedTime = SDL_GetTicks() - startTime;

        /* Si trop peu de temps s'est écoulé, on met en pause le programme */
        if(elapsedTime < FRAMERATE_MILLISECONDS) {
            SDL_Delay(FRAMERATE_MILLISECONDS - elapsedTime);
        }
    }

    /* Libération de l'espace mémoire alloué aux primitives, points etc */
    deletePrimitive(&primitiveList);

    /* Liberation des ressources associées à la SDL */ 
    SDL_Quit();

    return EXIT_SUCCESS;
}
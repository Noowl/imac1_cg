#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>

static unsigned int WINDOW_WIDTH = 800;
static unsigned int WINDOW_HEIGHT = 800;
static const unsigned int BIT_PER_PIXEL = 32;
static const Uint32 FRAMERATE_MILLISECONDS = 1000 / 60;

void drawSquare(int full);
void drawLandmark();
void drawCircle(int full);

void drawSquare(int full){
    GLenum typeDePrimitive;
    if (full == 0) typeDePrimitive = GL_LINE_LOOP;
    else typeDePrimitive = GL_QUADS;
    glBegin(typeDePrimitive);
        glVertex2f(-1 , 1);
        glVertex2f(1, 1);
        glVertex2f(1, -1);
        glVertex2f(-1, -1);
    glEnd();
}

void drawCircle(int full){
    float i,teta;
    GLenum typeDePrimitive;
    if (full == 0) typeDePrimitive = GL_LINE_LOOP;
    else typeDePrimitive = GL_POLYGON;
    glBegin(typeDePrimitive);
        teta = 0;
        for(i = 0.0; i <= 1.0; i += 0.01){
            teta = (float)i*(float)2*3.14159265359;
            glVertex2f(1*cos(teta),1*sin(teta));
        }
    glEnd();
}

void resizeViewport() {
    glViewport(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1., 1., -1., 1.);
    SDL_SetVideoMode(WINDOW_WIDTH, WINDOW_HEIGHT, BIT_PER_PIXEL, SDL_OPENGL | SDL_RESIZABLE);
}

GLuint createTexture(const char* theFileName){
    SDL_Surface* surface;
    surface = IMG_Load(theFileName);
    if (surface == NULL){
        printf("Erreur lors du chargement de l'image\n");
    }
    GLuint textureID;
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexImage2D(
        GL_TEXTURE_2D,
        0,
        GL_RGBA,
        surface->w,
        surface->h,
        0,
        GL_RGBA,
        GL_UNSIGNED_BYTE,
        surface->pixels);
    glBindTexture(GL_TEXTURE_2D, 0);
    SDL_FreeSurface(surface);
    return textureID;
}

void afficheTexture(GLuint idTexture){
    float i,teta;
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glBindTexture(GL_TEXTURE_2D, idTexture);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_POLYGON);
        teta = 0;
        for(i = 0.0; i <= 1.0; i += 0.01){
            teta = (float)i*(float)2*3.14159265359;
            glTexCoord2f(0.5*(cos(teta)+1),-0.5*(sin(teta)+1));
            glVertex2f(cos(teta),sin(teta));
        }
    glEnd();
    
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_BLEND);
    glBindTexture(GL_TEXTURE_2D, 0);
}

void clearTexture(GLuint* idTexture){
    glDeleteTextures(1,idTexture);
}

float recalculate(float n,float in){
	return in * pow(10,(-n));
}

int main(int argc, char** argv) {
	float zoom, moveX, moveY;
	moveY = moveX = 0;
	zoom = 6.9;
	//int i;
    time_t now;
    struct tm *date;

    // Initialisation de la SDL
    if(-1 == SDL_Init(SDL_INIT_VIDEO)) {
        fprintf(stderr, "Impossible d'initialiser la SDL. Fin du programme.\n");
        return EXIT_FAILURE;
    }

    // Ouverture d'une fenêtre et création d'un contexte OpenGL
    if(NULL == SDL_SetVideoMode(WINDOW_WIDTH, WINDOW_HEIGHT, BIT_PER_PIXEL, SDL_OPENGL | SDL_RESIZABLE)) {
        fprintf(stderr, "Impossible d'ouvrir la fenetre. Fin du programme.\n");
        return EXIT_FAILURE;
    }
    SDL_WM_SetCaption("td04", NULL);
    resizeViewport();

    GLuint jupiter = createTexture("./textures/jupiter.jpg");
    GLuint terre = createTexture("./textures/earth_daymap.jpg");
    GLuint mars = createTexture("./textures/mars.jpg");
    GLuint mercure = createTexture("./textures/mercury.jpg");
    GLuint neptune = createTexture("./textures/neptune.jpg");
    GLuint saturne = createTexture("./textures/saturn.jpg");
    GLuint sun = createTexture("./textures/sun.jpg");
    GLuint uranus = createTexture("./textures/uranus.jpg");
    GLuint venus = createTexture("./textures/venus_surface.jpg");

    int loop = 1;
    glClearColor(0.1, 0.1, 0.1 ,1.0);
    while(loop) {

        Uint32 startTime = SDL_GetTicks();

        // TODO: Code de dessin

        glClear(GL_COLOR_BUFFER_BIT);

        

        now = time(0);
        if ((date = localtime (&now)) == NULL) {
            printf ("Error extracting time stuff\n");
            return 1;
        }

        /* Horloge

        glPushMatrix();
        	glColor3ub(255,255,255);
        	drawCircle(1);
        glPopMatrix();

        glPushMatrix();
        	glColor3ub(0,0,0);
        	glScalef(0.98,0.98,1);
        	drawCircle(0);
        glPopMatrix();

        glPushMatrix();
        	glColor3ub(0,0,0);
        	glRotatef(90 -(360*date->tm_sec/60), 0.0, 0.0, 1.0);
        	glTranslatef(0.4,0,1);
        	glScalef(0.5,0.005,1);
        	drawSquare(1);
        glPopMatrix();

        glPushMatrix();
        	glColor3ub(0,0,0);
        	glRotatef(90 -(360*date->tm_min/60), 0.0, 0.0, 1.0);
        	glTranslatef(0.4,0,1);
        	glScalef(0.4,0.009,1);
        	drawSquare(1);
        glPopMatrix();

        glPushMatrix();
        	glColor3ub(0,0,0);
        	glRotatef(90 -(360*date->tm_hour/12), 0.0, 0.0, 1.0);
        	glTranslatef(0.05,0,1);
        	glScalef(0.1,0.013,1);
        	drawSquare(1);
        glPopMatrix();

        for (i = 0; i < 12; i++){
        	glPushMatrix();
        		glColor3ub(0,0,0);
        		glRotatef(90 -(360*i/12), 0.0, 0.0, 1.0);
        		glTranslatef(0.9,0,1);
        		glScalef(0.05,0.005,1);
        		drawSquare(1);
        	glPopMatrix();
        }

        for (i = 0; i < 60; i++){
        	glPushMatrix();
        		glColor3ub(0,0,0);
        		glRotatef(90 -(360*i/60), 0.0, 0.0, 1.0);
        		glTranslatef(0.9,0,1);
        		glScalef(0.05,0.001,1);
        		drawSquare(1);
        	glPopMatrix();
        } */

        /* Soleil */

        glPushMatrix();
        	glColor3ub(255,255,0);
        	glTranslatef(moveX,moveY,1);
			glScalef(recalculate(zoom,1.4*pow(10,6)),recalculate(zoom,1.4*pow(10,6)),1);
        	afficheTexture(sun);
        glPopMatrix();

        /* Mercure */

        glPushMatrix();
        	glColor3ub(150,150,150);
            glRotatef((360*date->tm_sec/55), 0.0, 0.0, 1.0);
        	glTranslatef(moveX+recalculate(zoom,1.4*pow(10,6))+recalculate(zoom,5.8*pow(10,4)),moveY,1);
        	glScalef(recalculate(zoom,4.9*pow(10,3)),recalculate(zoom,4.9*pow(10,3)),1);
        	afficheTexture(mercure);
        glPopMatrix();

        /* Vénus */

        glPushMatrix();
        	glColor3ub(200,200,120);
            glRotatef((360*date->tm_sec/90), 0.0, 0.0, 1.0);
        	glTranslatef(moveX+recalculate(zoom,1.4*pow(10,6))+recalculate(zoom,1.1*pow(10,5)),moveY,1);
        	glScalef(recalculate(zoom,1.2*pow(10,4)),recalculate(zoom,1.2*pow(10,4)),1);
        	afficheTexture(venus);
        glPopMatrix();

        /* Terre */

        glPushMatrix();
        	glColor3ub(100,100,200);
            glRotatef((360*date->tm_sec/100), 0.0, 0.0, 1.0);
        	glTranslatef(moveX+recalculate(zoom,1.4*pow(10,6))+recalculate(zoom,1.5*pow(10,5)),moveY,1);
        	glScalef(recalculate(zoom,1.3*pow(10,4)),recalculate(zoom,1.3*pow(10,4)),1);
        	afficheTexture(terre);
        glPopMatrix();

        /* Mars */

        glPushMatrix();
        	glColor3ub(250,250,100);
            glRotatef((360*date->tm_sec/110), 0.0, 0.0, 1.0);
        	glTranslatef(moveX+recalculate(zoom,1.4*pow(10,6))+recalculate(zoom,2.3*pow(10,5)),moveY,1);
        	glScalef(recalculate(zoom,6.8*pow(10,3)),recalculate(zoom,6.8*pow(10,3)),1);
        	afficheTexture(mars);
        glPopMatrix();

        /* Jupiter */
        glPushMatrix();
        	glColor3ub(230,230,150);
            glRotatef((360*date->tm_sec/153), 0.0, 0.0, 1.0);        	
            glTranslatef(moveX+recalculate(zoom,1.4*pow(10,6))+recalculate(zoom,7.8*pow(10,5)),moveY,1);
        	glScalef(recalculate(zoom,1.4*pow(10,5)),recalculate(zoom,1.4*pow(10,5)),1);
        	afficheTexture(jupiter);
        glPopMatrix();

        /* Saturne */

        glPushMatrix();
        	glColor3ub(255,255,0);
            glRotatef((360*date->tm_sec/164), 0.0, 0.0, 1.0);
        	glTranslatef(moveX+recalculate(zoom,1.4*pow(10,6))+recalculate(zoom,1.4*pow(10,6)),moveY,1);
        	glScalef(recalculate(zoom,1.2*pow(10,5)),recalculate(zoom,1.2*pow(10,5)),1);
        	afficheTexture(saturne);
        glPopMatrix();

        /* Uranus */

        glPushMatrix();
        	glColor3ub(50,50,255);
            glRotatef((360*date->tm_sec/175), 0.0, 0.0, 1.0);
        	glTranslatef(moveX+recalculate(zoom,1.4*pow(10,6))+recalculate(zoom,2.9*pow(10,6)),moveY,1);
        	glScalef(recalculate(zoom,5.1*pow(10,4)),recalculate(zoom,5.1*pow(10,4)),1);
        	afficheTexture(uranus);
        glPopMatrix();

        /* Neptune */

        glPushMatrix();
        	glColor3ub(91,93,223);
            glRotatef((360*date->tm_sec/182), 0.0, 0.0, 1.0);
        	glTranslatef(moveX+recalculate(zoom,1.4*pow(10,6))+recalculate(zoom,4.5*pow(10,6)),moveY,1);
        	glScalef(recalculate(zoom,4.9*pow(10,4)),recalculate(zoom,4.9*pow(10,4)),1);
        	afficheTexture(neptune);
        glPopMatrix();

        /* Pluton */

        glPushMatrix();
        	glColor3ub(220,220,220);
            glRotatef((360*date->tm_sec/182), 0.0, 0.0, 1.0);
        	glTranslatef(moveX+recalculate(zoom,1.4*pow(10,6))+recalculate(zoom,6.0*pow(10,6)),moveY,1);
        	glScalef(recalculate(zoom,2.3*pow(10,3)),recalculate(zoom,2.3*pow(10,3)),1);
        	drawCircle(1);
        glPopMatrix();

        // Fin du code de dessin

        SDL_Event e;
        while(SDL_PollEvent(&e)) {

            switch(e.type) {

            	 case SDL_KEYDOWN:
                    if (e.key.keysym.sym == SDLK_KP_PLUS)
    				    zoom -= 0.025;
                    if (e.key.keysym.sym == SDLK_KP_MINUS)
    				    zoom += 0.025;
    				if (e.key.keysym.sym == SDLK_z)
    					moveY += 0.01;
    				if (e.key.keysym.sym == SDLK_s)
    					moveY -= 0.01;
    				if (e.key.keysym.sym == SDLK_d)
    					moveX += 0.01;
    				if (e.key.keysym.sym == SDLK_q)
    					moveX -= 0.01;
                    break;

                case SDL_QUIT:
                    loop = 0;
                    break;

                case SDL_VIDEORESIZE:
                    WINDOW_WIDTH = e.resize.w;
                    WINDOW_HEIGHT = e.resize.h;
                    resizeViewport();
                    break;

                default:
                    break;
            }
        }

        SDL_GL_SwapBuffers();
        Uint32 elapsedTime = SDL_GetTicks() - startTime;
        if(elapsedTime < FRAMERATE_MILLISECONDS) {
            SDL_Delay(FRAMERATE_MILLISECONDS - elapsedTime);
        }
    }

    /* TP 4 : AVANT EXO BONUS 
    glDeleteTextures(1,&texture1);*/
    clearTexture(&jupiter);
    clearTexture(&terre);
    clearTexture(&mars);
    clearTexture(&mercure);
    clearTexture(&neptune);
    clearTexture(&saturne);
    clearTexture(&sun);
    clearTexture(&uranus);
    clearTexture(&venus);

    // Liberation des ressources associées à la SDL
    SDL_Quit();

    return EXIT_SUCCESS;
}

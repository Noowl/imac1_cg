#include <SDL/SDL.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

/* Dimensions de la fenêtre */
static unsigned int WINDOW_WIDTH = 400;
static unsigned int WINDOW_HEIGHT = 400;

/* Taille du repère */

#define TAILLE_REPERE 100

/* Nombre de bits par pixel de la fenêtre */
static const unsigned int BIT_PER_PIXEL = 32;

/* Nombre minimal de millisecondes separant le rendu de deux images */
static const Uint32 FRAMERATE_MILLISECONDS = 1000 / 60;

static int alpha, beta, ceta;

/* Prototypes des fonctions */
void resizeModif();
void drawSquare(int full);
void drawLandmark();
void drawCircle(int full);
void drawRoundedSquare(float size);
GLuint drawFirstArm();
GLuint drawSecondArm();
GLuint drawThirdArm();

/* Fonctions d'affichage */

/* Fonction qui ne retourne rien et redimensionne la fenêtre et le viewport */
void resizeModif(){
	SDL_SetVideoMode(WINDOW_WIDTH, WINDOW_HEIGHT, BIT_PER_PIXEL, SDL_OPENGL | SDL_RESIZABLE | SDL_GL_DOUBLEBUFFER);
    glViewport(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-100., 100., -100., 100.);
}

void drawSquare(int full){
    GLenum typeDePrimitive;
    if (full == 0) typeDePrimitive = GL_LINE_LOOP;
    else typeDePrimitive = GL_QUADS;
    glBegin(typeDePrimitive);
        glVertex2f(-1 , 1);
        glVertex2f(1, 1);
        glVertex2f(1, -1);
        glVertex2f(-1, -1);
    glEnd();
}

void drawLandmark(){
    glBegin(GL_LINES);
        glColor3ub(255, 0, 0);
        glVertex2f(-TAILLE_REPERE , 0);
        glVertex2f(TAILLE_REPERE, 0);
        glColor3ub(0, 255, 0);
        glVertex2f(0 , TAILLE_REPERE);
        glVertex2f(0, -TAILLE_REPERE);
    glEnd();
}

void drawCircle(int full){
    float i,teta;
    GLenum typeDePrimitive;
    if (full == 0) typeDePrimitive = GL_LINE_LOOP;
    else typeDePrimitive = GL_POLYGON;
    glBegin(typeDePrimitive);
        teta = 0;
        for(i = 0.0; i <= 1.0; i += 0.01){
            teta = (float)i*(float)2*3.14159265359;
            glVertex2f(1*cos(teta),1*sin(teta));
        }
    glEnd();
}

void drawRoundedSquare(float size){
    size = size / 2;
    glPushMatrix();
        glScalef((size/2),size,1);
        drawSquare(1);
    glPopMatrix();
    glPushMatrix();
        glScalef(size,(size/2),1);
        drawSquare(1);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(-(size/2),(size/2),0);
        glScalef((size/2),(size/2),1);
        drawCircle(1);
    glPopMatrix();
    glPushMatrix();
        glTranslatef((size/2),(size/2),0);
        glScalef((size/2),(size/2),1);
        drawCircle(1);
    glPopMatrix();
    glPushMatrix();
        glTranslatef((size/2),-(size/2),0);
        glScalef((size/2),(size/2),1);
        drawCircle(1);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(-(size/2),-(size/2),0);
        glScalef((size/2),(size/2),1);
        drawCircle(1);
    glPopMatrix();
}

GLuint drawFirstArm(){
    GLuint firstArm;
    firstArm = glGenLists (1);
    glNewList(firstArm, GL_COMPILE);
       glPushMatrix();
           glScalef(10,10,1);
           drawCircle(1);
       glPopMatrix();
       glPushMatrix();
           glTranslatef(60,0,0);
           glScalef(5,5,1);
           drawCircle(1);
       glPopMatrix();
       glBegin(GL_QUADS);
           glVertex2f(0, -10);
           glVertex2f(60, -5);
           glVertex2f(60, 5);
           glVertex2f(0, 10);
       glEnd();
    glEndList();


    glColor3ub(0, 0, 255);
    glPushMatrix();
        glTranslatef(60,0,0);
        glRotatef(beta, 0.0, 0.0, 1.0);
        glCallList(drawSecondArm());
    glPopMatrix();

    return firstArm;
}

GLuint drawSecondArm(){
    GLuint secondArm;
    secondArm = glGenLists (1);
    glNewList(secondArm, GL_COMPILE);
        glPushMatrix();
            glTranslatef(0,0,0);
            drawRoundedSquare(10);
        glPopMatrix();
        glPushMatrix();
            glTranslatef(50,0,0);
            drawRoundedSquare(10);
        glPopMatrix();
        glPushMatrix();
            glTranslatef(25,0,0);
            glScalef(23,3,1);
            drawSquare(1);
        glPopMatrix();
    glEndList();


    glColor3ub(0, 255, 0);
    glPushMatrix();
        glTranslatef(50,0,0);
        glRotatef(ceta, 0.0, 0.0, 1.0);
         glCallList(drawThirdArm());
    glPopMatrix();
    glPushMatrix();
        glTranslatef(50,0,0);
        glRotatef(ceta+180, 0.0, 0.0, 1.0);
         glCallList(drawThirdArm());
    glPopMatrix();

    return secondArm;
}

GLuint drawThirdArm(){
    GLuint thirdArm;
    thirdArm = glGenLists (1);
    glNewList(thirdArm, GL_COMPILE);
        glPushMatrix();
            glTranslatef(0,0,0);
            drawRoundedSquare(6);
        glPopMatrix();
        glPushMatrix();
            glTranslatef(40,0,0);
            glScalef(3,3,1);
            drawCircle(1);
        glPopMatrix();
        glPushMatrix();
            glTranslatef(20,0,0);
            glScalef(20,2,1);
            drawSquare(1);
        glPopMatrix();
    glEndList();

    return thirdArm;
}

/* Fonction principale */
int main(int argc, char** argv) {
    int r,g,b; /* Composantes de couleurs rgb, affichage : 0 = Dessin | 1 = Choix couleur*/
    float thickness; /* Cordonnée en x, coordonnées en y, épaisseur du point/trait */

    ceta = beta = alpha = 0;
    r = g = b = 255; /* Initialisation des  composantes de couleur à blanc */
    thickness = 2.; /* Initialisation de l'apaisseur à 2 */

    /* Initialisation de la SDL */
    if(-1 == SDL_Init(SDL_INIT_VIDEO)) {
        fprintf(stderr, "Impossible d'initialiser la SDL. Fin du programme.\n");
        return EXIT_FAILURE;
    }
    
    /* Ouverture d'une fenêtre et création d'un contexte OpenGL */
    if(NULL == SDL_SetVideoMode(WINDOW_WIDTH, WINDOW_HEIGHT, BIT_PER_PIXEL, SDL_OPENGL | SDL_GL_DOUBLEBUFFER | SDL_RESIZABLE)) {
        fprintf(stderr, "Impossible d'ouvrir la fenetre. Fin du programme.\n");
        return EXIT_FAILURE;
    }

    resizeModif();
    
    /* Titre de la fenêtre */
    SDL_WM_SetCaption("PaintImac", NULL);
    
    /* Initialisation des paramètres de dessin */
    glColor3ub(r,g,b); 
    glPointSize(thickness); 
    glLineWidth(thickness);

    /* Boucle d'affichage */
    int loop = 1;
    while(loop){

        /* Récupération du temps au début de la boucle */
        Uint32 startTime = SDL_GetTicks();
        
        /* Placer ici le code de dessin */

        ceta = beta = alpha += 1;

        glColor3ub(r,g,b);
        glClearColor(0,0,0,0);
            glClear(GL_COLOR_BUFFER_BIT);

        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        drawLandmark();

        glColor3ub(255, 0, 0);
        glPushMatrix();
            glTranslatef(-60,0,0);
            glRotatef(alpha, 0.0, 0.0, 1.0);
            glCallList(drawFirstArm());
        glPopMatrix();
        
        /* Boucle traitant les evenements */
        SDL_Event e;
        while(SDL_PollEvent(&e)) {

            /* L'utilisateur ferme la fenêtre : */
            if(e.type == SDL_QUIT) {
                loop = 0;
                break;
            }
            
            /* Quelques exemples de traitement d'evenements : */
            switch(e.type) {
                /* Clic souris */
                case SDL_MOUSEBUTTONDOWN:
                    
                    break;

                case SDL_MOUSEBUTTONUP:
                    if (e.button.button == SDL_BUTTON_RIGHT){
                        
                    }
                    break;

                case SDL_MOUSEMOTION:
                    
                break;

                /* Touche clavier pushed */
                case SDL_KEYDOWN:
			        if (e.key.keysym.sym == SDLK_q) {
    				    loop = 0;
                    }
                    break;

        		case SDL_VIDEORESIZE:
        			WINDOW_WIDTH = e.resize.w;
        			WINDOW_HEIGHT = e.resize.h;
        			resizeModif();			
        			break;

                default:
                    break;
            }
        }

        SDL_GL_SwapBuffers();

        /* Calcul du temps écoulé */
        Uint32 elapsedTime = SDL_GetTicks() - startTime;

        /* Si trop peu de temps s'est écoulé, on met en pause le programme */
        if(elapsedTime < FRAMERATE_MILLISECONDS) {
            SDL_Delay(FRAMERATE_MILLISECONDS - elapsedTime);
        }
    }

    /* Liberation des ressources associées à la SDL */ 
    SDL_Quit();

    return EXIT_SUCCESS;
}
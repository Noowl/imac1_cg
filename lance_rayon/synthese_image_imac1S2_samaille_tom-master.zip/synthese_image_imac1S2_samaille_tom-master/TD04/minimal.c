#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

static unsigned int WINDOW_WIDTH = 800;
static unsigned int WINDOW_HEIGHT = 800;
static const unsigned int BIT_PER_PIXEL = 32;
static const Uint32 FRAMERATE_MILLISECONDS = 1000 / 60;
const char* filename = "logo_imac_400x400.jpg";
const char* file0 = "./numbers/0.png";
const char* file1 = "./numbers/1.png";
const char* file2 = "./numbers/2.png";
const char* file3 = "./numbers/3.png";
const char* file4 = "./numbers/4.png";
const char* file5 = "./numbers/5.png";
const char* file6 = "./numbers/6.png";
const char* file7 = "./numbers/7.png";
const char* file8 = "./numbers/8.png";
const char* file9 = "./numbers/9.png";
const char* fileCol = "./numbers/colon.png";

void resizeViewport() {
    glViewport(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1., 1., -1., 1.);
    SDL_SetVideoMode(WINDOW_WIDTH, WINDOW_HEIGHT, BIT_PER_PIXEL, SDL_OPENGL | SDL_RESIZABLE);
}

GLuint createTexture(const char* theFileName){
    SDL_Surface* surface;
    surface = IMG_Load(theFileName);
    if (surface == NULL){
        printf("Erreur lors du chargement de l'image\n");
    }
    GLuint textureID;
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexImage2D(
        GL_TEXTURE_2D,
        0,
        GL_RGBA,
        surface->w,
        surface->h,
        0,
        GL_RGBA,
        GL_UNSIGNED_BYTE,
        surface->pixels);
    glBindTexture(GL_TEXTURE_2D, 0);
    SDL_FreeSurface(surface);
    return textureID;
}

void afficheTexture(GLuint idTexture){
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glBindTexture(GL_TEXTURE_2D, idTexture);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_QUADS);
        glTexCoord2f(0 , 0);
        glVertex2f(-0.5 , 0.5);
        glTexCoord2f(1 , 0);
        glVertex2f(0.5, 0.5);
        glTexCoord2f(1 , 1);
        glVertex2f(0.5, -0.5);
        glTexCoord2f(0 , 1);
        glVertex2f(-0.5, -0.5);
    glEnd();
    
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_BLEND);
    glBindTexture(GL_TEXTURE_2D, 0);
}

void clearTexture(GLuint* idTexture){
    glDeleteTextures(1,idTexture);
}

int main(int argc, char** argv) {
    GLuint dh,uh,dm,um,ds,us;
    time_t now;
    struct tm *date;

    // Initialisation de la SDL
    if(-1 == SDL_Init(SDL_INIT_VIDEO)) {
        fprintf(stderr, "Impossible d'initialiser la SDL. Fin du programme.\n");
        return EXIT_FAILURE;
    }

    // Ouverture d'une fenêtre et création d'un contexte OpenGL
    if(NULL == SDL_SetVideoMode(WINDOW_WIDTH, WINDOW_HEIGHT, BIT_PER_PIXEL, SDL_OPENGL | SDL_RESIZABLE)) {
        fprintf(stderr, "Impossible d'ouvrir la fenetre. Fin du programme.\n");
        return EXIT_FAILURE;
    }
    SDL_WM_SetCaption("td04", NULL);
    resizeViewport();

    // TODO: Chargement et traitement de la texture

    GLuint id0 = createTexture(file0);
    GLuint id1 = createTexture(file1);
    GLuint id2 = createTexture(file2);
    GLuint id3 = createTexture(file3);
    GLuint id4 = createTexture(file4);
    GLuint id5 = createTexture(file5);
    GLuint id6 = createTexture(file6);
    GLuint id7 = createTexture(file7);
    GLuint id8 = createTexture(file8);
    GLuint id9 = createTexture(file9);
    GLuint id10 = createTexture(fileCol);

    /* TP 4 : AVANT EXO BONUS
    SDL_Surface *SurfaceLogoImac;

    SurfaceLogoImac = IMG_Load(filename);
    if (SurfaceLogoImac == NULL){
        printf("Erreur lors du chargement de l'image\n");
    }
    GLuint texture1;
    glGenTextures(1, &texture1);
    glBindTexture(GL_TEXTURE_2D, texture1);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexImage2D(
    GL_TEXTURE_2D,
    0,
    GL_RGBA,
    SurfaceLogoImac->w,
    SurfaceLogoImac->h,
    0,
    GL_RGBA,
    GL_UNSIGNED_BYTE,
    SurfaceLogoImac->pixels);
    glBindTexture(GL_TEXTURE_2D, 0);*/

    // TODO: Libération des données CPU
    // SDL_FreeSurface(SurfaceLogoImac);

    int loop = 1;
    glClearColor(0.1, 0.1, 0.1 ,1.0);
    while(loop) {

        Uint32 startTime = SDL_GetTicks();

        // TODO: Code de dessin

        glClear(GL_COLOR_BUFFER_BIT);

        now = time(0);
        if ((date = localtime (&now)) == NULL) {
            printf ("Error extracting time stuff\n");
            return 1;
        }
        /* printf("%02d:%02d:%02d\n", date->tm_hour, date->tm_min, date->tm_sec); */
        switch(date->tm_sec){
            case 0:
                ds = id0;
                us = id0;
                break;
            case 1:
                ds = id0;
                us = id1;
                break;
            case 2:
                ds = id0;
                us = id2;
                break;
            case 3:
                ds = id0;
                us = id3;
                break;
            case 4:
                ds = id0;
                us = id4;
                break;
            case 5:
                ds = id0;
                us = id5;
                break;
            case 6:
                ds = id0;
                us = id6;
                break;
            case 7:
                ds = id0;
                us = id7;
                break;
            case 8:
                ds = id0;
                us = id8;
                break;
            case 9:
                ds = id0;
                us = id9;
                break;
            case 10:
                ds = id1;
                us = id0;
                break;
            case 11:
                ds = id1;
                us = id1;
                break;
            case 12:
                ds = id1;
                us = id2;
                break;
            case 13:
                ds = id1;
                us = id3;
                break;
            case 14:
                ds = id1;
                us = id4;
                break;
            case 15:
                ds = id1;
                us = id5;
                break;
            case 16:
                ds = id1;
                us = id6;
                break;
            case 17:
                ds = id1;
                us = id7;
                break;
            case 18:
                ds = id1;
                us = id8;
                break;
            case 19:
                ds = id1;
                us = id9;
                break;
            case 20:
                ds = id2;
                us = id0;
                break;
            case 21:
                ds = id2;
                us = id1;
                break;
            case 22:
                ds = id2;
                us = id2;
                break;
            case 23:
                ds = id2;
                us = id3;
                break;
            case 24:
                ds = id2;
                us = id4;
                break;
            case 25:
                ds = id2;
                us = id5;
                break;
            case 26:
                ds = id2;
                us = id6;
                break;
            case 27:
                ds = id2;
                us = id7;
                break;
            case 28:
                ds = id2;
                us = id8;
                break;
            case 29:
                ds = id2;
                us = id9;
                break;
            case 30:
                ds = id3;
                us = id0;
                break;
            case 31:
                ds = id3;
                us = id1;
                break;
            case 32:
                ds = id3;
                us = id2;
                break;
            case 33:
                ds = id3;
                us = id3;
                break;
            case 34:
                ds = id3;
                us = id4;
                break;
            case 35:
                ds = id3;
                us = id5;
                break;
            case 36:
                ds = id3;
                us = id6;
                break;
            case 37:
                ds = id3;
                us = id7;
                break;
            case 38:
                ds = id3;
                us = id8;
                break;
            case 39:
                ds = id3;
                us = id9;
                break;
            case 40:
                ds = id4;
                us = id0;
                break;
            case 41:
                ds = id4;
                us = id1;
                break;
            case 42:
                ds = id4;
                us = id2;
                break;
            case 43:
                ds = id4;
                us = id3;
                break;
            case 44:
                ds = id4;
                us = id4;
                break;
            case 45:
                ds = id4;
                us = id5;
                break;
            case 46:
                ds = id4;
                us = id6;
                break;
            case 47:
                ds = id4;
                us = id7;
                break;
            case 48:
                ds = id4;
                us = id8;
                break;
            case 49:
                ds = id4;
                us = id9;
                break;
            case 50:
                ds = id5;
                us = id0;
                break;
            case 51:
                ds = id5;
                us = id1;
                break;
            case 52:
                ds = id5;
                us = id2;
                break;
            case 53:
                ds = id5;
                us = id3;
                break;
            case 54:
                ds = id5;
                us = id4;
                break;
            case 55:
                ds = id5;
                us = id5;
                break;
            case 56:
                ds = id5;
                us = id6;
                break;
            case 57:
                ds = id5;
                us = id7;
                break;
            case 58:
                ds = id5;
                us = id8;
                break;
            case 59:
                ds = id5;
                us = id9;
                break;
            default: 
                ds = id0;
                us = id0;
                break;
        }
        switch(date->tm_min){
            case 0:
                dm = id0;
                um = id0;
                break;
            case 1:
                dm = id0;
                um = id1;
                break;
            case 2:
                dm = id0;
                um = id2;
                break;
            case 3:
                dm = id0;
                um = id3;
                break;
            case 4:
                dm = id0;
                um = id4;
                break;
            case 5:
                dm = id0;
                um = id5;
                break;
            case 6:
                dm = id0;
                um = id6;
                break;
            case 7:
                dm = id0;
                um = id7;
                break;
            case 8:
                dm = id0;
                um = id8;
                break;
            case 9:
                dm = id0;
                um = id9;
                break;
            case 10:
                dm = id1;
                um = id0;
                break;
            case 11:
                dm = id1;
                um = id1;
                break;
            case 12:
                dm = id1;
                um = id2;
                break;
            case 13:
                dm = id1;
                um = id3;
                break;
            case 14:
                dm = id1;
                um = id4;
                break;
            case 15:
                dm = id1;
                um = id5;
                break;
            case 16:
                dm = id1;
                um = id6;
                break;
            case 17:
                dm = id1;
                um = id7;
                break;
            case 18:
                dm = id1;
                um = id8;
                break;
            case 19:
                dm = id1;
                um = id9;
                break;
            case 20:
                dm = id2;
                um = id0;
                break;
            case 21:
                dm = id2;
                um = id1;
                break;
            case 22:
                dm = id2;
                um = id2;
                break;
            case 23:
                dm = id2;
                um = id3;
                break;
            case 24:
                dm = id2;
                um = id4;
                break;
            case 25:
                dm = id2;
                um = id5;
                break;
            case 26:
                dm = id2;
                um = id6;
                break;
            case 27:
                dm = id2;
                um = id7;
                break;
            case 28:
                dm = id2;
                um = id8;
                break;
            case 29:
                dm = id2;
                um = id9;
                break;
            case 30:
                dm = id3;
                um = id0;
                break;
            case 31:
                dm = id3;
                um = id1;
                break;
            case 32:
                dm = id3;
                um = id2;
                break;
            case 33:
                dm = id3;
                um = id3;
                break;
            case 34:
                dm = id3;
                um = id4;
                break;
            case 35:
                dm = id3;
                um = id5;
                break;
            case 36:
                dm = id3;
                um = id6;
                break;
            case 37:
                dm = id3;
                um = id7;
                break;
            case 38:
                dm = id3;
                um = id8;
                break;
            case 39:
                dm = id3;
                um = id9;
                break;
            case 40:
                dm = id4;
                um = id0;
                break;
            case 41:
                dm = id4;
                um = id1;
                break;
            case 42:
                dm = id4;
                um = id2;
                break;
            case 43:
                dm = id4;
                um = id3;
                break;
            case 44:
                dm = id4;
                um = id4;
                break;
            case 45:
                dm = id4;
                um = id5;
                break;
            case 46:
                dm = id4;
                um = id6;
                break;
            case 47:
                dm = id4;
                um = id7;
                break;
            case 48:
                dm = id4;
                um = id8;
                break;
            case 49:
                dm = id4;
                um = id9;
                break;
            case 50:
                dm = id5;
                um = id0;
                break;
            case 51:
                dm = id5;
                um = id1;
                break;
            case 52:
                dm = id5;
                um = id2;
                break;
            case 53:
                dm = id5;
                um = id3;
                break;
            case 54:
                dm = id5;
                um = id4;
                break;
            case 55:
                dm = id5;
                um = id5;
                break;
            case 56:
                dm = id5;
                um = id6;
                break;
            case 57:
                dm = id5;
                um = id7;
                break;
            case 58:
                dm = id5;
                um = id8;
                break;
            case 59:
                dm = id5;
                um = id9;
                break;
            default: 
                dm = id0;
                um = id0;
                break;
        }
        switch(date->tm_hour){
            case 0:
                dh = id0;
                uh = id0;
                break;
            case 1:
                dh = id0;
                uh = id1;
                break;
            case 2:
                dh = id0;
                uh = id2;
                break;
            case 3:
                dh = id0;
                uh = id3;
                break;
            case 4:
                dh = id0;
                uh = id4;
                break;
            case 5:
                dh = id0;
                uh = id5;
                break;
            case 6:
                dh = id0;
                uh = id6;
                break;
            case 7:
                dh = id0;
                uh = id7;
                break;
            case 8:
                dh = id0;
                uh = id8;
                break;
            case 9:
                dh = id0;
                uh = id9;
                break;
            case 10:
                dh = id1;
                uh = id0;
                break;
            case 11:
                dh = id1;
                uh = id1;
                break;
            case 12:
                dh = id1;
                uh = id2;
                break;
            case 13:
                dh = id1;
                uh = id3;
                break;
            case 14:
                dh = id1;
                uh = id4;
                break;
            case 15:
                dh = id1;
                uh = id5;
                break;
            case 16:
                dh = id1;
                uh = id6;
                break;
            case 17:
                dh = id1;
                uh = id7;
                break;
            case 18:
                dh = id1;
                uh = id8;
                break;
            case 19:
                dh = id1;
                uh = id9;
                break;
            case 20:
                dh = id2;
                uh = id0;
                break;
            case 21:
                dh = id2;
                uh = id1;
                break;
            case 22:
                dh = id2;
                uh = id2;
                break;
            case 23:
                dh = id2;
                uh = id3;
                break;
            case 24:
                dh = id2;
                uh = id4;
                break;
            case 25:
                dh = id2;
                uh = id5;
                break;
            case 26:
                dh = id2;
                uh = id6;
                break;
            case 27:
                dh = id2;
                uh = id7;
                break;
            case 28:
                dh = id2;
                uh = id8;
                break;
            case 29:
                dh = id2;
                uh = id9;
                break;
            case 30:
                dh = id3;
                uh = id0;
                break;
            case 31:
                dh = id3;
                uh = id1;
                break;
            case 32:
                dh = id3;
                uh = id2;
                break;
            case 33:
                dh = id3;
                uh = id3;
                break;
            case 34:
                dh = id3;
                uh = id4;
                break;
            case 35:
                dh = id3;
                uh = id5;
                break;
            case 36:
                dh = id3;
                uh = id6;
                break;
            case 37:
                dh = id3;
                uh = id7;
                break;
            case 38:
                dh = id3;
                uh = id8;
                break;
            case 39:
                dh = id3;
                uh = id9;
                break;
            case 40:
                dh = id4;
                uh = id0;
                break;
            case 41:
                dh = id4;
                uh = id1;
                break;
            case 42:
                dh = id4;
                uh = id2;
                break;
            case 43:
                dh = id4;
                uh = id3;
                break;
            case 44:
                dh = id4;
                uh = id4;
                break;
            case 45:
                dh = id4;
                uh = id5;
                break;
            case 46:
                dh = id4;
                uh = id6;
                break;
            case 47:
                dh = id4;
                uh = id7;
                break;
            case 48:
                dh = id4;
                uh = id8;
                break;
            case 49:
                dh = id4;
                uh = id9;
                break;
            case 50:
                dh = id5;
                uh = id0;
                break;
            case 51:
                dh = id5;
                uh = id1;
                break;
            case 52:
                dh = id5;
                uh = id2;
                break;
            case 53:
                dh = id5;
                uh = id3;
                break;
            case 54:
                dh = id5;
                uh = id4;
                break;
            case 55:
                dh = id5;
                uh = id5;
                break;
            case 56:
                dh = id5;
                uh = id6;
                break;
            case 57:
                dh = id5;
                uh = id7;
                break;
            case 58:
                dh = id5;
                uh = id8;
                break;
            case 59:
                dh = id5;
                uh = id9;
                break;
            default: 
                dh = id0;
                uh = id0;
                break;
        }
        glPushMatrix();
            glTranslatef(-0.35,0,1);
            glScalef(0.1,0.15,1);
            afficheTexture(dh);
        glPopMatrix();
        glPushMatrix();
            glTranslatef(-0.25,0,1);
            glScalef(0.1,0.15,1);
            afficheTexture(uh);
        glPopMatrix();
        glPushMatrix();
            glTranslatef(-0.15,0,1);
            glScalef(0.1,0.15,1);
            afficheTexture(id10);
        glPopMatrix();
        glPushMatrix();
            glTranslatef(-0.05,0,1);
            glScalef(0.1,0.15,1);
            afficheTexture(dm);
        glPopMatrix();
        glPushMatrix();
            glTranslatef(0.05,0,1);
            glScalef(0.1,0.15,1);
            afficheTexture(um);
        glPopMatrix();
        glPushMatrix();
            glTranslatef(0.15,0,1);
            glScalef(0.1,0.15,1);
            afficheTexture(id10);
        glPopMatrix();
        glPushMatrix();
            glTranslatef(0.25,0,1);
            glScalef(0.1,0.15,1);
            afficheTexture(ds);
        glPopMatrix();
        glPushMatrix();
            glTranslatef(0.35,0,1);
            glScalef(0.1,0.15,1);
            afficheTexture(us);
        glPopMatrix();

        /* TP 4 : AVANT EXO BONUS 
        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, texture1);

        glBegin(GL_QUADS);
            glTexCoord2f(0 , 0);
            glVertex2f(-0.5 , 0.5);
            glTexCoord2f(1 , 0);
            glVertex2f(0.5, 0.5);
            glTexCoord2f(1 , 1);
            glVertex2f(0.5, -0.5);
            glTexCoord2f(0 , 1);
            glVertex2f(-0.5, -0.5);
        glEnd();
        
        glDisable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, 0); */

        // Fin du code de dessin

        SDL_Event e;
        while(SDL_PollEvent(&e)) {

            switch(e.type) {

                case SDL_QUIT:
                    loop = 0;
                    break;

                case SDL_VIDEORESIZE:
                    WINDOW_WIDTH = e.resize.w;
                    WINDOW_HEIGHT = e.resize.h;
                    resizeViewport();

                default:
                    break;
            }
        }

        SDL_GL_SwapBuffers();
        Uint32 elapsedTime = SDL_GetTicks() - startTime;
        if(elapsedTime < FRAMERATE_MILLISECONDS) {
            SDL_Delay(FRAMERATE_MILLISECONDS - elapsedTime);
        }
    }

    // TODO: Libération des données GPU

    clearTexture(&id0);
    clearTexture(&id1);
    clearTexture(&id2);
    clearTexture(&id3);
    clearTexture(&id4);
    clearTexture(&id5);
    clearTexture(&id6);
    clearTexture(&id7);
    clearTexture(&id8);
    clearTexture(&id9);
    clearTexture(&id10);


    /* TP 4 : AVANT EXO BONUS 
    glDeleteTextures(1,&texture1);*/

    // Liberation des ressources associées à la SDL
    SDL_Quit();

    return EXIT_SUCCESS;
}
